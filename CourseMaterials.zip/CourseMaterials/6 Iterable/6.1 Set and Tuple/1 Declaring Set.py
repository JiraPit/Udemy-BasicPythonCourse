my_set = {1,2,3,4}

print(type(my_set))
print(my_set)
print(len(my_set))

