my_tuple = (1,2,3,4)

print(type(my_tuple))
print(my_tuple)
print(len(my_tuple))

