my_set = {1,1,2,2,3,3}

for s in my_set:
    print(s*10)

    