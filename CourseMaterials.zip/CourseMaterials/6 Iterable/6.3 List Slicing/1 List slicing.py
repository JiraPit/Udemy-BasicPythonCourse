my_list = ["a", "b", "c", "d", "e", "f"]

print(my_list[2:])
print(my_list[0:2])
print(my_list[2:4])
print(my_list[0:-2])


