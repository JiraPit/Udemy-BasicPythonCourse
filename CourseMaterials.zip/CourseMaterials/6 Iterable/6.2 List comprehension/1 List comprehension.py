my_list = list(range(1,11))

x = [e*2 for e in my_list]

print(x)

