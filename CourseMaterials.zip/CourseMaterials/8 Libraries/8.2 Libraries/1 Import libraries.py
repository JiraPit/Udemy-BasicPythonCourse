import numpy as np

matrix = np.ones((3,3))
print(matrix)

