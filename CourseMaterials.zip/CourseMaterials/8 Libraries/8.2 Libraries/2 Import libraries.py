import numpy as np
import matplotlib.pyplot as plt

random = np.random.randn(100)
plt.plot(range(100),random)
plt.show()

