from math import sin,cos,tan, factorial

print(sin(5))
print(cos(5))
print(tan(5))
print(factorial(5))

