import math as m

a = 6

print(m.sin(a))
print(m.cos(a))
print(m.tan(a))
print(m.factorial(a))

