import math

a = 6

print(math.sin(a))
print(math.cos(a))
print(math.tan(a))
print(math.factorial(a))

