class Bedroom:
    bed_size = 6
    door_colour = "white"

johns_bedroom = Bedroom()

print(johns_bedroom.bed_size)
print(johns_bedroom.door_colour)



