class Bedroom:
    bed_size = 6

johns_bedroom = Bedroom()

print(type(johns_bedroom))

