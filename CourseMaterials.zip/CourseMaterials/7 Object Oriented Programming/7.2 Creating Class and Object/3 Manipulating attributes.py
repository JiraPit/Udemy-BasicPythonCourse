class Bedroom:
    bed_size = 6
    door_colour = "white"

johns_bedroom = Bedroom()

print(johns_bedroom.bed_size)

johns_bedroom.bed_size = 4
print(johns_bedroom.bed_size)

