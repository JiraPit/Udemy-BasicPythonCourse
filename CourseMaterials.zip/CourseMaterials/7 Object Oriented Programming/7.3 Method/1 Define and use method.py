class Bedroom:
    def buy_carpet(self):
        print("ซื้อพรมแล้ว!!")
        
johns_bedroom = Bedroom()

johns_bedroom.buy_carpet()

