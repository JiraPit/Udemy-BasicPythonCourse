my_score = 40

if my_score >= 80:
    print("สอบผ่าน-ยอดเยี่ยม")
elif my_score >= 50:
    print("สอบผ่าน")
else:
    print("สอบตก")




