my_score = 20

if my_score >= 50:
    print("สอบผ่าน")


