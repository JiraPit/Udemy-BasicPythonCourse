my_score = 50

if my_score >= 50:
    print("สอบผ่าน")
else:
    print("สอบตก")


