print(type(lambda x:x**4))
print((lambda x:x**4)(5))

(lambda x:x**4)
