my_lambda = lambda x: x**4

print(type(my_lambda))
print(my_lambda(4))
