my_lambda = lambda x: print(x)

print(type(my_lambda))
my_lambda(4)

