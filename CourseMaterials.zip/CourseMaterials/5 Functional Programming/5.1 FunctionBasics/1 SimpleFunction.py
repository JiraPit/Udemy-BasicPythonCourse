def times_table():
    for i in range(1,13):
        print("5 x ",i," = ",5*i)

times_table()