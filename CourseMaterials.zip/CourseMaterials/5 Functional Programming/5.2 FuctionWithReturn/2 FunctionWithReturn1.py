def fourth_power(n):
    return n**4

x = fourth_power(3)

print(x)

