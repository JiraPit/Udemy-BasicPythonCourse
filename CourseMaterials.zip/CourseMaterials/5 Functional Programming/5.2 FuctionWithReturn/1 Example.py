numbers = [1,2,3]

x = len(numbers)
print(x)

