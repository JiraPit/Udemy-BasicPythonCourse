y = 5

def some_function(x):
    a = x+3
    print(a)

print(y)
print(x)
print(a)

