print("Hello, World")
print(5)
print(5,"is called five")

