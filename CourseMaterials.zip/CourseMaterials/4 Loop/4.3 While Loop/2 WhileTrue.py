while True:
    i = int(input("กรอกตัวเลข "))
    print(i**3)

    