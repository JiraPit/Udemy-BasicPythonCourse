for i in range(0,5,1):
    print("ในการวนครั้งนี้ มีค่า i เป็น",i)

