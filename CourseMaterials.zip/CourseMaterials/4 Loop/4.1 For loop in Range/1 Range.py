r = range(0,10,1)

print(type(r))
print(r)


