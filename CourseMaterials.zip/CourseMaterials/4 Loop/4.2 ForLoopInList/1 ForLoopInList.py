alphabets = ["a","b","c","d","e"]

for x in alphabets:
    print("the upper case of ",x," is ",x.upper())

    