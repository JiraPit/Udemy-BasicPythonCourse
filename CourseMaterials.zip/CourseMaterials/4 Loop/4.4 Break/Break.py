while True:
    i = int(input("กรอกตัวเลข "))
    if i == 0:
        break
    print(i**3)

print("การทำงานเสร็จสิ้นแล้ว")