x = int(input("กรอกอายุของท่าน: "))
print(type(x))
print(x+2)

