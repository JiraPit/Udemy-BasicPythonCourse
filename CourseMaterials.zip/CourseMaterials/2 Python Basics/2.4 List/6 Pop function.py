my_list = [1,2,3,4,5]

my_list.pop(2)
my_list.pop(2)

print(my_list)