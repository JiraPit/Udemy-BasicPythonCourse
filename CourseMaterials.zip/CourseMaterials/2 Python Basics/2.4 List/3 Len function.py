my_list = "Hello"
print(len(my_list))

