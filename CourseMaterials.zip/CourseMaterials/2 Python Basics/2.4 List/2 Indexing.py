# my_list = [1,2,3,4,5]
# x = my_list[3]

my_string = "hello"
x = my_string[1]
print(x)

