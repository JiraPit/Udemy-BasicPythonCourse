my_list = [1,2,3,4,5]

print(type(my_list))
print(my_list)

