my_list = [1,2,3,4,5]

my_list.append("a")

print(my_list)
print(len(my_list))

