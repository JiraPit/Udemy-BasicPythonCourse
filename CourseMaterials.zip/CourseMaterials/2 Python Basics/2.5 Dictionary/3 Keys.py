my_dict = {
    "name":"Henry",
    "age":21,
    "gender":"male"
    }

# print(my_dict.keys())
print(type(list(my_dict.keys())))

