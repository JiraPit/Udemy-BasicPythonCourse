my_dict = {
    "name":"Henry",
    "age":21,
    "gender":"male"
    }

print(my_dict.values())
print(type( list(my_dict.values()) ))

