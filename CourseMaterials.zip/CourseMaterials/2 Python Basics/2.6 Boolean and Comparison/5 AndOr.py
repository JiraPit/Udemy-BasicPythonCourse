x = 5==3
y = "H" in "Hello"

print(x and y)
print(x or y)

