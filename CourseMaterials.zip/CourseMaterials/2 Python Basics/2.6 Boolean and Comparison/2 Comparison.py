x = 5
y = 4

equal = x!=y
more = x>y
less = x<y

print(equal, more, less)

