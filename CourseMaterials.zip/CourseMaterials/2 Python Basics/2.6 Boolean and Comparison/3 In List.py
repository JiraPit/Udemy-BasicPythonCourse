my_list = [5,6,7]

print(5 in my_list)
print("c" in my_list)

