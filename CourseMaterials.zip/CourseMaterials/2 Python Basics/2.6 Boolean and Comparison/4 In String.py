name = "Jacky"

print("p" in name)
print("c" in name)

