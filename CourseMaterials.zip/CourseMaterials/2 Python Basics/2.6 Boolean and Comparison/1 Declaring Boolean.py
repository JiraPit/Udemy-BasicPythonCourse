x = True

print(type(x))
print(x)

