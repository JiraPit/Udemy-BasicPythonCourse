x = 5
y = 2
z = "Hello, World"

print("x มีค่าเท่ากับ ",x)
print("y มีค่าเท่ากับ ",y)
print("z มีค่าเท่ากับ ",z)

