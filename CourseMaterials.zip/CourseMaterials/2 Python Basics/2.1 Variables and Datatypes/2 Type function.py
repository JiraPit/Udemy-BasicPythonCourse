age = 20
name = "Henry"

print(type(age))
print(type(name))

