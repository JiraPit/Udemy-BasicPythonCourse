x = 5
y = 2.5

print(type(x))
print(type(y))

