Pi = 3.1415

print(Pi)
print(round(Pi,2))

