x = 6
y = 3

print(x+y)
print(x-y)
print(x*y)
print(x/y)


