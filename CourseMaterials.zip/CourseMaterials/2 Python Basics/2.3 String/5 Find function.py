name = "Henry Oliver"

index = name.find("r")

print(index)

