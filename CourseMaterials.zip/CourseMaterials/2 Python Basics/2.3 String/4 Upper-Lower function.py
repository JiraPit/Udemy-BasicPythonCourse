name = "Henry"

lowercase = name.lower()
uppercase = name.upper()

print(name)
print(lowercase)
print(uppercase)

