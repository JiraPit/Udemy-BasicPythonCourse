x = "What's your name?"

print(type(x))

