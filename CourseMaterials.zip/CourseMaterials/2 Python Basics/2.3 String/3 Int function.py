x = "3"
y = "2"
sum = int(x) + int(y)

print(sum)

