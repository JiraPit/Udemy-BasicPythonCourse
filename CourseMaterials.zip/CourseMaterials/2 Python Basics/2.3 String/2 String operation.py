name = "Hen"+"ry"

print(name)

