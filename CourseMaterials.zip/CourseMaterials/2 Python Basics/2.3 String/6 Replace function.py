sentence = "I love Henry."

sentence_for_Jack = sentence.replace("Henry", "Jack")

print(sentence_for_Jack)

